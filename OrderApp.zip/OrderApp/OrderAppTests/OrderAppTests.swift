//
//  OrderAppTests.swift
//  OrderAppTests
//
//  Created by David Santiago Jamaica Galvis on 5/9/25.
//

import Testing
@testable import OrderApp

struct OrderAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
