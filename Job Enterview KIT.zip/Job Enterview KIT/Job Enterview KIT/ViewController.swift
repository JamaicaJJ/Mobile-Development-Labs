//
//  ViewController.swift
//  Job Enterview KIT
//
//  Created by David Santiago Jamaica Galvis on 7/15/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

